package DAO;

import Conexao.Conexao;
import Model.Endereco;
import Model.Solicitante;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ConsultaSolicitanteDAO {

    public static Solicitante buscarLogin(
            String email,
            String senha
    ) {

        String sql = """
                SELECT
                    s.id,
                    s.CNPJ_Solicitante,
                    s.Nom_Solicitante,
                    s.telefone_solicitante,
                    s.email_solicitante,
                    s.Senha_Solicitante,

                    e.id AS endereco_id,
                    e.cep,
                    e.estado,
                    e.estado_UF,
                    e.cidade,
                    e.bairro,
                    e.rua,
                    e.num_end,
                    e.complemento

                FROM solicitante s

                INNER JOIN endereco e
                ON s.Endereco_FK = e.id

                WHERE s.email_solicitante = ?
                AND s.Senha_Solicitante = ?

                LIMIT 1
                """;

        try (
                Connection conexao = Conexao.conectar();
                PreparedStatement comando =
                        conexao.prepareStatement(sql)
        ) {

            comando.setString(1, email);
            comando.setString(2, senha);

            ResultSet resultado =
                    comando.executeQuery();

            if (resultado.next()) {

                Endereco endereco =
                        new Endereco(
                                resultado.getString("cep"),
                                resultado.getString("estado"),
                                resultado.getString("estado_UF"),
                                resultado.getString("cidade"),
                                resultado.getString("bairro"),
                                resultado.getString("rua"),
                                resultado.getString("num_end"),
                                resultado.getString("complemento")
                        );

                endereco.setId(
                        resultado.getInt("endereco_id")
                );


                Solicitante solicitante =
                        new Solicitante(
                                resultado.getString(
                                        "CNPJ_Solicitante"
                                ),
                                resultado.getString(
                                        "Nom_Solicitante"
                                ),
                                resultado.getString(
                                        "telefone_solicitante"
                                ),
                                resultado.getString(
                                        "email_solicitante"
                                ),
                                resultado.getString(
                                        "Senha_Solicitante"
                                ),
                                endereco
                        );

                solicitante.setId(
                        resultado.getInt("id")
                );

                return solicitante;
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return null;
    }
}