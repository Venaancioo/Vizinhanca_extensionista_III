package DAO;

import Conexao.Conexao;
import Model.Voluntario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class VoluntarioDAO {

    public static boolean salvar(Voluntario voluntario) {

        String sql = """
                INSERT INTO voluntario
                (
                    Cpf_Voluntario,
                    Nom_Voluntario,
                    Telefone_Voluntario,
                    Email_Voluntario,
                    Senha_Voluntario,
                    Habilidade_Voluntario,
                    Endereco_Fk,
                    Genero_FK
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """;

        try (
                Connection conexao = Conexao.conectar();
                PreparedStatement comando =
                        conexao.prepareStatement(sql)
        ) {

            comando.setString(
                    1,
                    voluntario.getCpf()
            );

            comando.setString(
                    2,
                    voluntario.getNomeCompleto()
            );

            comando.setString(
                    3,
                    voluntario.getTelefone()
            );

            comando.setString(
                    4,
                    voluntario.getEmail()
            );

            comando.setString(
                    5,
                    voluntario.getSenha()
            );

            comando.setString(
                    6,
                    voluntario.getHabilidades()
            );

            comando.setInt(
                    7,
                    voluntario.getEndereco().getId()
            );

            comando.setInt(
                    8,
                    voluntario.getGenero().getCodigo()
            );

            comando.executeUpdate();

            System.out.println(
                    "Voluntário salvo com sucesso!"
            );

            return true;

        } catch (Exception e) {

            e.printStackTrace();
            return false;
        }
    }


    public static boolean cpfExiste(String cpf) {

        String sql = """
                SELECT 1
                FROM voluntario
                WHERE Cpf_Voluntario = ?
                LIMIT 1
                """;

        try (
                Connection conexao = Conexao.conectar();
                PreparedStatement comando =
                        conexao.prepareStatement(sql)
        ) {

            comando.setString(1, cpf);

            ResultSet resultado =
                    comando.executeQuery();

            return resultado.next();

        } catch (Exception e) {

            e.printStackTrace();
            return false;
        }
    }


    public static boolean emailExiste(String email) {

        String sql = """
                SELECT 1
                FROM voluntario
                WHERE Email_Voluntario = ?
                LIMIT 1
                """;

        try (
                Connection conexao = Conexao.conectar();
                PreparedStatement comando =
                        conexao.prepareStatement(sql)
        ) {

            comando.setString(1, email);

            ResultSet resultado =
                    comando.executeQuery();

            return resultado.next();

        } catch (Exception e) {

            e.printStackTrace();
            return false;
        }
    }
}