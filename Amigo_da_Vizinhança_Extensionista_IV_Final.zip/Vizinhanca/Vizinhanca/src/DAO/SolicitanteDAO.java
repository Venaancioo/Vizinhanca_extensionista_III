package DAO;

import Conexao.Conexao;
import Model.Solicitante;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class SolicitanteDAO {

    public static boolean salvar(
            Solicitante solicitante,
            int enderecoId) {

        String sql = """
                INSERT INTO solicitante
                (
                    CNPJ_Solicitante,
                    Nom_Solicitante,
                    telefone_solicitante,
                    email_solicitante,
                    Senha_Solicitante,
                    Endereco_FK
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """;

        try {
            Connection conexao = Conexao.conectar();

            PreparedStatement comando =
                    conexao.prepareStatement(sql);

            comando.setString(
                    1,
                    solicitante.getCnpj()
            );

            comando.setString(
                    2,
                    solicitante.getRazaoSocial()
            );

            comando.setString(
                    3,
                    solicitante.getTelefone()
            );

            comando.setString(
                    4,
                    solicitante.getEmail()
            );

            comando.setString(
                    5,
                    solicitante.getSenha()
            );

            comando.setInt(
                    6,
                    enderecoId
            );

            comando.executeUpdate();

            System.out.println(
                    "Solicitante salvo com sucesso!"
            );

            return true;

        } catch (Exception e) {

            e.printStackTrace();
            return false;
        }
    }


    public static boolean cnpjExiste(String cnpj) {

        String sql = """
                SELECT 1
                FROM solicitante
                WHERE CNPJ_Solicitante = ?
                LIMIT 1
                """;

        try {
            Connection conexao = Conexao.conectar();

            PreparedStatement comando =
                    conexao.prepareStatement(sql);

            comando.setString(1, cnpj);

            ResultSet resultado =
                    comando.executeQuery();

            return resultado.next();

        } catch (Exception e) {

            e.printStackTrace();
            return false;
        }
    }
}