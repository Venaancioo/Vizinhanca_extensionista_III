package DAO;

import Conexao.Conexao;
import Model.Estado;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class EstadoDAO {

    public static List<Estado> listarTodos() {

        List<Estado> estados = new ArrayList<>();

        String sql = """
                SELECT id, nome, uf
                FROM estado
                ORDER BY nome
                """;

        try {
            Connection conexao = Conexao.conectar();

            PreparedStatement comando =
                    conexao.prepareStatement(sql);

            ResultSet resultado = comando.executeQuery();

            while (resultado.next()) {

                Estado estado = new Estado(
                        resultado.getInt("id"),
                        resultado.getString("nome"),
                        resultado.getString("uf")
                );

                estados.add(estado);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return estados;
    }
}