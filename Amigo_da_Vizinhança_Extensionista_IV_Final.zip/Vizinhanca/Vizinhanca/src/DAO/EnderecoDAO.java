package DAO;

import Conexao.Conexao;
import Model.Endereco;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class EnderecoDAO {

    public static int salvar(Endereco endereco) {

        String sql = """
                INSERT INTO endereco
                (
                    cep,
                    estado,
                    estado_UF,
                    cidade,
                    bairro,
                    rua,
                    num_end,
                    complemento
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """;

        try {
            Connection conexao = Conexao.conectar();

            PreparedStatement comando =
                    conexao.prepareStatement(
                            sql,
                            Statement.RETURN_GENERATED_KEYS
                    );

            comando.setString(1, endereco.getCep());
            comando.setString(2, endereco.getEstado());
            comando.setString(3, endereco.getUf());
            comando.setString(4, endereco.getCidade());
            comando.setString(5, endereco.getBairro());
            comando.setString(6, endereco.getRua());
            comando.setString(7, endereco.getNumero());
            comando.setString(8, endereco.getComplemento());

            comando.executeUpdate();

            ResultSet resultado =
                    comando.getGeneratedKeys();

            if (resultado.next()) {
                return resultado.getInt(1);
            }

        } catch (Exception e) {

            e.printStackTrace();
            return 0;
        }

        return 0;
    }
}