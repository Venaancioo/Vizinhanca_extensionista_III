package DAO;

import Conexao.Conexao;
import Model.Endereco;
import Model.Genero;
import Model.Voluntario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ConsultaVoluntarioDAO {

    public static List<Voluntario> buscarPorCidade(String cidade) {

        List<Voluntario> voluntarios = new ArrayList<>();

        String sql = """
                SELECT
                    v.Cpf_Voluntario,
                    v.Nom_Voluntario,
                    v.Telefone_Voluntario,
                    v.Email_Voluntario,
                    v.Senha_Voluntario,
                    v.Habilidade_Voluntario,

                    e.id AS endereco_id,
                    e.cep,
                    e.estado,
                    e.estado_UF,
                    e.cidade,
                    e.bairro,
                    e.rua,
                    e.num_end,
                    e.complemento,

                    g.id AS genero_id,
                    g.tipo_servico

                FROM voluntario v

                INNER JOIN endereco e
                ON v.Endereco_Fk = e.id

                INNER JOIN genero g
                ON v.Genero_FK = g.id

                WHERE LOWER(e.cidade) LIKE LOWER(?)
                """;

        try (
                Connection conexao = Conexao.conectar();
                PreparedStatement comando =
                        conexao.prepareStatement(sql)
        ) {

            comando.setString(1, "%" + cidade + "%");

            ResultSet resultado =
                    comando.executeQuery();

            while (resultado.next()) {

                voluntarios.add(
                        criarVoluntario(resultado)
                );
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return voluntarios;
    }


    public static List<Voluntario> buscarPorGeneroECidade(
            int generoId,
            String cidade
    ) {

        List<Voluntario> voluntarios =
                new ArrayList<>();

        String sql = """
                SELECT
                    v.Cpf_Voluntario,
                    v.Nom_Voluntario,
                    v.Telefone_Voluntario,
                    v.Email_Voluntario,
                    v.Senha_Voluntario,
                    v.Habilidade_Voluntario,

                    e.id AS endereco_id,
                    e.cep,
                    e.estado,
                    e.estado_UF,
                    e.cidade,
                    e.bairro,
                    e.rua,
                    e.num_end,
                    e.complemento,

                    g.id AS genero_id,
                    g.tipo_servico

                FROM voluntario v

                INNER JOIN endereco e
                ON v.Endereco_Fk = e.id

                INNER JOIN genero g
                ON v.Genero_FK = g.id

                WHERE v.Genero_FK = ?
                AND LOWER(e.cidade) LIKE LOWER(?)
                """;

        try (
                Connection conexao = Conexao.conectar();
                PreparedStatement comando =
                        conexao.prepareStatement(sql)
        ) {

            comando.setInt(1, generoId);

            comando.setString(
                    2,
                    "%" + cidade + "%"
            );

            ResultSet resultado =
                    comando.executeQuery();

            while (resultado.next()) {

                voluntarios.add(
                        criarVoluntario(resultado)
                );
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return voluntarios;
    }


    public static Voluntario buscarLogin(
            String email,
            String senha
    ) {

        String sql = """
                SELECT
                    v.Cpf_Voluntario,
                    v.Nom_Voluntario,
                    v.Telefone_Voluntario,
                    v.Email_Voluntario,
                    v.Senha_Voluntario,
                    v.Habilidade_Voluntario,

                    e.id AS endereco_id,
                    e.cep,
                    e.estado,
                    e.estado_UF,
                    e.cidade,
                    e.bairro,
                    e.rua,
                    e.num_end,
                    e.complemento,

                    g.id AS genero_id,
                    g.tipo_servico

                FROM voluntario v

                INNER JOIN endereco e
                ON v.Endereco_Fk = e.id

                INNER JOIN genero g
                ON v.Genero_FK = g.id

                WHERE v.Email_Voluntario = ?
                AND v.Senha_Voluntario = ?
                LIMIT 1
                """;

        try (
                Connection conexao = Conexao.conectar();
                PreparedStatement comando =
                        conexao.prepareStatement(sql)
        ) {

            comando.setString(1, email);
            comando.setString(2, senha);

            ResultSet resultado =
                    comando.executeQuery();

            if (resultado.next()) {

                return criarVoluntario(resultado);
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return null;
    }


    private static Voluntario criarVoluntario(
            ResultSet resultado
    ) throws Exception {

        Endereco endereco = new Endereco(
                resultado.getString("cep"),
                resultado.getString("estado"),
                resultado.getString("estado_UF"),
                resultado.getString("cidade"),
                resultado.getString("bairro"),
                resultado.getString("rua"),
                resultado.getString("num_end"),
                resultado.getString("complemento")
        );

        endereco.setId(
                resultado.getInt("endereco_id")
        );


        Genero genero = new Genero(
                resultado.getInt("genero_id"),
                resultado.getString("tipo_servico")
        );


        return new Voluntario(
                resultado.getString("Cpf_Voluntario"),
                resultado.getString("Nom_Voluntario"),
                resultado.getString("Telefone_Voluntario"),
                resultado.getString("Email_Voluntario"),
                resultado.getString("Senha_Voluntario"),
                resultado.getString("Habilidade_Voluntario"),
                genero,
                endereco
        );
    }
}