package DAO;

import Conexao.Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import Model.Solicitacao;

public class SolicitacaoDAO {
    public static boolean salvar (Solicitacao solicitacao){
        String sql = """
            INSERT INTO solicitacao
            (
                Genero_FK,
                descricao_Solicitacao,
                Endereco_solicitacao,
                Solicitante_FK
            )
            VALUES (?, ?, ?, ?)
            """;

        try {
            Connection conexao = Conexao.conectar();

            PreparedStatement comando =
                    conexao.prepareStatement(sql);

            comando.setInt(1, solicitacao.getGenero().getCodigo());
            comando.setString(2, solicitacao.getDescricao());
            comando.setInt(3, solicitacao.getEndereco().getId());
            comando.setInt(4, solicitacao.getSolicitante().getId());

            comando.executeUpdate();

            System.out.println("Solicitação salva com sucesso!");

            return true;

        }catch (Exception e) {
            e.printStackTrace();
            return false;
        }

    }
}
