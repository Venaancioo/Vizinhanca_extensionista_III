package DAO;

import Conexao.Conexao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import Model.Genero;

public class GeneroDAO {

    public static List<Genero> listar() {

        List<Genero> generos = new ArrayList<>();

        String sql = "SELECT id, tipo_servico FROM genero";

        try {
            Connection conexao = Conexao.conectar();

            PreparedStatement comando =
                    conexao.prepareStatement(sql);

            ResultSet resultado = comando.executeQuery();

            while(resultado.next()) {

                int id = resultado.getInt("id");
                String nome = resultado.getString("tipo_servico");

                generos.add(
                        new Genero(id, nome)
                );
            }

        } catch(Exception e) {
            e.printStackTrace();
        }
        return generos;
    }
}