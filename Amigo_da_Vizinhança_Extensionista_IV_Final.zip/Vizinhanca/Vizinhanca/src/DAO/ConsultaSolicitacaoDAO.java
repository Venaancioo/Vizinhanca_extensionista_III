package DAO;

import Conexao.Conexao;
import Model.Endereco;
import Model.Genero;
import Model.Solicitante;
import Model.Solicitacao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ConsultaSolicitacaoDAO {

    public static List<Solicitacao> listar() {

        List<Solicitacao> solicitacoes = new ArrayList<>();

        String sql = """
                SELECT
                    s.id,
                    s.descricao_Solicitacao,

                    g.id AS genero_id,
                    g.tipo_servico,

                    e.id AS endereco_id,
                    e.cep,
                    e.estado,
                    e.estado_UF,
                    e.cidade,
                    e.bairro,
                    e.rua,
                    e.num_end,
                    e.complemento,

                    so.id AS solicitante_id,
                    so.CNPJ_Solicitante,
                    so.Nom_Solicitante,
                    so.telefone_solicitante,
                    so.email_solicitante,
                    so.Senha_Solicitante

                FROM solicitacao s

                INNER JOIN genero g
                ON s.Genero_FK = g.id

                INNER JOIN endereco e
                ON s.Endereco_solicitacao = e.id

                INNER JOIN solicitante so
                ON s.Solicitante_FK = so.id
                """;

        try (
                Connection conexao = Conexao.conectar();
                PreparedStatement comando =
                        conexao.prepareStatement(sql)
        ) {

            ResultSet resultado =
                    comando.executeQuery();

            while (resultado.next()) {

                solicitacoes.add(
                        criarSolicitacao(resultado)
                );
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return solicitacoes;
    }


    public static List<Solicitacao> buscarPorCidade(
            String cidade
    ) {

        List<Solicitacao> solicitacoes =
                new ArrayList<>();

        String sql = """
                SELECT
                    s.id,
                    s.descricao_Solicitacao,

                    g.id AS genero_id,
                    g.tipo_servico,

                    e.id AS endereco_id,
                    e.cep,
                    e.estado,
                    e.estado_UF,
                    e.cidade,
                    e.bairro,
                    e.rua,
                    e.num_end,
                    e.complemento,

                    so.id AS solicitante_id,
                    so.CNPJ_Solicitante,
                    so.Nom_Solicitante,
                    so.telefone_solicitante,
                    so.email_solicitante,
                    so.Senha_Solicitante

                FROM solicitacao s

                INNER JOIN genero g
                ON s.Genero_FK = g.id

                INNER JOIN endereco e
                ON s.Endereco_solicitacao = e.id

                INNER JOIN solicitante so
                ON s.Solicitante_FK = so.id

                WHERE LOWER(e.cidade) LIKE LOWER(?)
                """;

        try (
                Connection conexao = Conexao.conectar();
                PreparedStatement comando =
                        conexao.prepareStatement(sql)
        ) {

            comando.setString(
                    1,
                    "%" + cidade + "%"
            );

            ResultSet resultado =
                    comando.executeQuery();

            while (resultado.next()) {

                solicitacoes.add(
                        criarSolicitacao(resultado)
                );
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return solicitacoes;
    }


    public static List<Solicitacao> buscarPorGeneroECidade(
            int generoId,
            String cidade
    ) {

        List<Solicitacao> solicitacoes =
                new ArrayList<>();

        String sql = """
                SELECT
                    s.id,
                    s.descricao_Solicitacao,

                    g.id AS genero_id,
                    g.tipo_servico,

                    e.id AS endereco_id,
                    e.cep,
                    e.estado,
                    e.estado_UF,
                    e.cidade,
                    e.bairro,
                    e.rua,
                    e.num_end,
                    e.complemento,

                    so.id AS solicitante_id,
                    so.CNPJ_Solicitante,
                    so.Nom_Solicitante,
                    so.telefone_solicitante,
                    so.email_solicitante,
                    so.Senha_Solicitante

                FROM solicitacao s

                INNER JOIN genero g
                ON s.Genero_FK = g.id

                INNER JOIN endereco e
                ON s.Endereco_solicitacao = e.id

                INNER JOIN solicitante so
                ON s.Solicitante_FK = so.id

                WHERE s.Genero_FK = ?
                AND LOWER(e.cidade) LIKE LOWER(?)
                """;

        try (
                Connection conexao = Conexao.conectar();
                PreparedStatement comando =
                        conexao.prepareStatement(sql)
        ) {

            comando.setInt(
                    1,
                    generoId
            );

            comando.setString(
                    2,
                    "%" + cidade + "%"
            );

            ResultSet resultado =
                    comando.executeQuery();

            while (resultado.next()) {

                solicitacoes.add(
                        criarSolicitacao(resultado)
                );
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return solicitacoes;
    }


    private static Solicitacao criarSolicitacao(
            ResultSet resultado
    ) throws Exception {

        Genero genero = new Genero(
                resultado.getInt("genero_id"),
                resultado.getString("tipo_servico")
        );


        Endereco endereco = new Endereco(
                resultado.getString("cep"),
                resultado.getString("estado"),
                resultado.getString("estado_UF"),
                resultado.getString("cidade"),
                resultado.getString("bairro"),
                resultado.getString("rua"),
                resultado.getString("num_end"),
                resultado.getString("complemento")
        );

        endereco.setId(
                resultado.getInt("endereco_id")
        );


        Solicitante solicitante =
                new Solicitante(
                        resultado.getString("CNPJ_Solicitante"),
                        resultado.getString("Nom_Solicitante"),
                        resultado.getString("telefone_solicitante"),
                        resultado.getString("email_solicitante"),
                        resultado.getString("Senha_Solicitante"),
                        endereco
                );

        solicitante.setId(
                resultado.getInt("solicitante_id")
        );


        return new Solicitacao(
                resultado.getInt("id"),
                genero,
                resultado.getString(
                        "descricao_Solicitacao"
                ),
                endereco,
                solicitante
        );
    }
}