import DAO.*;
import Model.*;

import java.util.List;
import java.util.Scanner;

class Sistema {

    private Scanner scanner;
    private Solicitante solicitanteLogado;

    public Sistema() {
        this.scanner = new Scanner(System.in);
    }

    public void executar() {

        int opcao;

        do {

            System.out.println("""
                    
                    Digite o número da opção desejada:

                    1 - Cadastrar solicitante
                    2 - Entrar solicitante
                    3 - Cadastrar voluntário
                    4 - Entrar voluntário
                    0 - Sair
                    
                    """);

            opcao = Integer.parseInt(scanner.nextLine());

            switch (opcao) {

                case 1 -> cadastrarSolicitante();

                case 2 -> loginSolicitante();

                case 3 -> cadastrarVoluntario();

                case 4 -> entrarVoluntario();

                case 0 -> System.out.println("Saindo...");

                default -> System.out.println("Opção inválida!");
            }

        } while (opcao != 0);
    }


    private void cadastrarSolicitante() {

        System.out.println("Digite o CNPJ: ");
        String cnpj = scanner.nextLine();

        System.out.println("Digite a Razão Social: ");
        String razao = scanner.nextLine();

        System.out.println("Digite o telefone: ");
        String telefone = scanner.nextLine();

        System.out.println("Digite o email: ");
        String email = scanner.nextLine();


        String senha;
        String confirmaSenha;

        do {

            System.out.println("Digite a senha: ");
            senha = scanner.nextLine();

            System.out.println("Confirme a senha: ");
            confirmaSenha = scanner.nextLine();

            if (!senha.equals(confirmaSenha)) {

                System.out.println(
                        "As senhas não coincidem. Tente novamente!"
                );
            }

        } while (!senha.equals(confirmaSenha));


        // CRIAR ENDEREÇO

        Endereco endereco = criarEndereco();


        // SALVAR ENDEREÇO

        int idEndereco =
                EnderecoDAO.salvar(endereco);

        if (idEndereco == 0) {

            System.out.println(
                    "Erro ao salvar endereço."
            );

            return;
        }


        endereco.setId(idEndereco);


        // CRIAR SOLICITANTE

        Solicitante solicitante =
                new Solicitante(
                        cnpj,
                        razao,
                        telefone,
                        email,
                        senha,
                        endereco
                );


        // SALVAR SOLICITANTE

        boolean salvou =
                SolicitanteDAO.salvar(
                        solicitante,
                        idEndereco
                );


        if (salvou) {

            System.out.println(
                    "Model.Solicitante cadastrado com sucesso!"
            );

        } else {

            System.out.println(
                    "Erro ao cadastrar solicitante."
            );
        }
    }


    private void loginSolicitante() {

        System.out.println("Digite o email:");
        String email = scanner.nextLine();

        System.out.println("Digite a senha:");
        String senha = scanner.nextLine();


        Solicitante solicitante =
                ConsultaSolicitanteDAO.buscarLogin(
                        email,
                        senha
                );


        if (solicitante != null) {

            solicitanteLogado = solicitante;

            System.out.println(
                    "Login realizado com sucesso!"
            );

            entrarSolicitante();

        } else {

            System.out.println(
                    "Email ou senha incorretos."
            );
        }
    }


    private void entrarSolicitante() {

        int opcao;

        do {

            System.out.println("""
                    
                    1 - Cadastrar solicitação
                    2 - Pesquisar voluntário por cidade
                    0 - Menu anterior
                    
                    """);

            opcao =
                    Integer.parseInt(
                            scanner.nextLine()
                    );


            switch (opcao) {

                case 1 -> cadastrarSolicitacao();

                case 2 -> pesquisaVoluntario();

                case 0 ->
                        System.out.println(
                                "Voltando ao menu anterior..."
                        );

                default ->
                        System.out.println(
                                "Opção inválida!"
                        );
            }

        } while (opcao != 0);
    }


    private void pesquisaVoluntario() {

        System.out.println(
                "Digite a cidade para buscar voluntários: "
        );

        String cidade =
                scanner.nextLine();


        List<Voluntario> voluntarios =
                ConsultaVoluntarioDAO.buscarPorCidade(
                        cidade
                );


        if (voluntarios.isEmpty()) {

            System.out.println(
                    "Nenhum voluntário encontrado nessa cidade."
            );

            return;
        }


        for (Voluntario v : voluntarios) {

            v.exibir();

            System.out.println(
                    "------------------"
            );
        }
    }


    private void cadastrarVoluntario() {

        System.out.println("Digite o CPF: ");
        String cpf = scanner.nextLine();

        System.out.println("Digite o nome completo: ");
        String nome = scanner.nextLine();

        System.out.println("Digite o telefone: ");
        String tel = scanner.nextLine();

        System.out.println("Digite o email: ");
        String email = scanner.nextLine();


        String senha;
        String confirmaSenha;


        do {

            System.out.println("Digite a senha: ");
            senha = scanner.nextLine();

            System.out.println("Confirmar senha: ");
            confirmaSenha = scanner.nextLine();


            if (!senha.equals(confirmaSenha)) {

                System.out.println(
                        "As senhas não coincidem. Tente novamente!"
                );
            }

        } while (!senha.equals(confirmaSenha));


        // GÊNERO

        System.out.println(
                "Escolha o gênero de serviço:"
        );


        List<Genero> generos =
                GeneroDAO.listar();


        for (Genero g : generos) {

            System.out.println(g);
        }


        int opcao =
                Integer.parseInt(
                        scanner.nextLine()
                );


        Genero generoSelecionado = null;


        for (Genero g : generos) {

            if (g.getCodigo() == opcao) {

                generoSelecionado = g;

                break;
            }
        }


        if (generoSelecionado == null) {

            System.out.println(
                    "Gênero inválido."
            );

            return;
        }


        // HABILIDADES

        System.out.println(
                "Digite suas habilidades:"
        );

        String hab =
                scanner.nextLine();


        // ENDEREÇO

        Endereco end =
                criarEndereco();


        // SALVAR ENDEREÇO

        int idEndereco =
                EnderecoDAO.salvar(end);


        if (idEndereco == 0) {

            System.out.println(
                    "Erro ao salvar endereço."
            );

            return;
        }


        end.setId(idEndereco);


        // CRIAR VOLUNTÁRIO

        Voluntario voluntario =
                new Voluntario(
                        cpf,
                        nome,
                        tel,
                        email,
                        senha,
                        hab,
                        generoSelecionado,
                        end
                );


        // SALVAR VOLUNTÁRIO

        boolean salvou =
                VoluntarioDAO.salvar(
                        voluntario
                );


        if (salvou) {

            System.out.println(
                    "Voluntário cadastrado com sucesso!"
            );

        } else {

            System.out.println(
                    "Erro ao cadastrar voluntário."
            );
        }
    }


    private void cadastrarSolicitacao() {

        System.out.println(
                "Digite o gênero do serviço:"
        );


        List<Genero> generos =
                GeneroDAO.listar();


        for (Genero g : generos) {

            System.out.println(g);
        }


        int opcao =
                Integer.parseInt(
                        scanner.nextLine()
                );


        Genero generoSelecionado = null;


        for (Genero g : generos) {

            if (g.getCodigo() == opcao) {

                generoSelecionado = g;

                break;
            }
        }


        if (generoSelecionado == null) {

            System.out.println(
                    "Gênero inválido."
            );

            return;
        }


        System.out.println(
                "Digite a descrição do serviço:"
        );

        String descricao =
                scanner.nextLine();


        System.out.println(
                "Digite o endereço onde será realizado o serviço:"
        );


        // CRIAR ENDEREÇO

        Endereco endereco =
                criarEndereco();


        // SALVAR ENDEREÇO

        int idEndereco =
                EnderecoDAO.salvar(endereco);


        if (idEndereco == 0) {

            System.out.println(
                    "Erro ao salvar endereço."
            );

            return;
        }


        endereco.setId(idEndereco);


        // CRIAR SOLICITAÇÃO

        Solicitacao solicitacao =
                new Solicitacao(
                        0,
                        generoSelecionado,
                        descricao,
                        endereco,
                        solicitanteLogado
                );


        // SALVAR SOLICITAÇÃO

        boolean salvou =
                SolicitacaoDAO.salvar(
                        solicitacao
                );


        if (salvou) {

            System.out.println(
                    "Solicitação cadastrada com sucesso!"
            );

        } else {

            System.out.println(
                    "Erro ao cadastrar solicitação."
            );
        }
    }


    public void entrarVoluntario() {

        int opcao;


        do {

            System.out.println("""
                    
                    1 - Pesquisar solicitação por cidade
                    0 - Menu anterior
                    
                    """);


            opcao =
                    Integer.parseInt(
                            scanner.nextLine()
                    );


            switch (opcao) {

                case 1 ->
                        pesquisaSolicitacao();

                case 0 ->
                        System.out.println(
                                "Voltando ao menu anterior..."
                        );

                default ->
                        System.out.println(
                                "Opção inválida!"
                        );
            }


        } while (opcao != 0);
    }


    private void pesquisaSolicitacao() {

        System.out.println(
                "Digite a cidade para buscar solicitações:"
        );


        String cidade =
                scanner.nextLine();


        List<Solicitacao> solicitacoes =
                ConsultaSolicitacaoDAO.buscarPorCidade(
                        cidade
                );


        if (solicitacoes.isEmpty()) {

            System.out.println(
                    "Nenhuma solicitação encontrada nessa cidade."
            );

            return;
        }


        for (Solicitacao s : solicitacoes) {

            s.exibir();

            System.out.println(
                    "--------------------"
            );
        }
    }


    private Endereco criarEndereco() {

        System.out.println("Digite o CEP:");
        String cep = scanner.nextLine();


        System.out.println("Digite o Estado:");
        String estado = scanner.nextLine();


        System.out.println("Digite a UF do Estado:");
        String uf = scanner.nextLine();


        System.out.println("Digite a Cidade:");
        String cidade = scanner.nextLine();


        System.out.println("Digite o Bairro:");
        String bairro = scanner.nextLine();


        System.out.println("Digite a Rua:");
        String rua = scanner.nextLine();


        System.out.println("Digite o Número:");
        String numero = scanner.nextLine();


        System.out.println("Digite o Complemento:");
        String complemento = scanner.nextLine();


        return new Endereco(
                cep,
                estado,
                uf,
                cidade,
                bairro,
                rua,
                numero,
                complemento
        );
    }
}