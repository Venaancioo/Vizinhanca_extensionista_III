package Controller;

import Util.Navegacao;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;

import java.io.IOException;

public class TelaInicialController {

    @FXML
    private void abrirLoginSolicitante(
            ActionEvent event
    ) throws IOException {

        Navegacao.trocarTela(
                (Node) event.getSource(),
                "/View/LoginSolicitante.fxml"
        );
    }


    @FXML
    private void abrirLoginVoluntario(
            ActionEvent event
    ) throws IOException {

        Navegacao.trocarTela(
                (Node) event.getSource(),
                "/View/LoginVoluntario.fxml"
        );
    }


    @FXML
    private void abrirEscolhaCadastro(
            ActionEvent event
    ) throws IOException {

        Navegacao.trocarTela(
                (Node) event.getSource(),
                "/View/EscolhaCadastro.fxml"
        );
    }


    @FXML
    private void sair() {

        Platform.exit();
    }
}