package Controller;

import DAO.EnderecoDAO;
import DAO.SolicitanteDAO;
import Model.Endereco;
import Model.Estado;
import Model.Solicitante;
import Util.Navegacao;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DialogPane;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.IOException;

public class CadastroSolicitanteController {

    @FXML
    private TextField campoCnpj;

    @FXML
    private TextField campoRazaoSocial;

    @FXML
    private TextField campoTelefone;

    @FXML
    private TextField campoEmail;

    @FXML
    private PasswordField campoSenha;

    @FXML
    private PasswordField campoConfirmarSenha;

    @FXML
    private TextField campoCep;

    @FXML
    private ComboBox<Estado> campoEstado;

    @FXML
    private TextField campoCidade;

    @FXML
    private TextField campoBairro;

    @FXML
    private TextField campoRua;

    @FXML
    private TextField campoNumero;

    @FXML
    private TextField campoComplemento;


    @FXML
    private void initialize() {

        System.out.println("Carregando estados do banco...");

        campoEstado.getItems().addAll(
                DAO.EstadoDAO.listarTodos()
        );

        System.out.println(
                "Estados carregados: "
                        + campoEstado.getItems().size()
        );
    }


    @FXML
    private void cadastrar() {

        System.out.println("=================================");
        System.out.println("BOTÃO CADASTRAR FOI CLICADO!");
        System.out.println("=================================");


        // ==============================
        // DADOS DO SOLICITANTE
        // ==============================

        String cnpj =
                campoCnpj.getText().replaceAll("\\D", "");

        String razaoSocial =
                campoRazaoSocial.getText();

        String telefone =
                campoTelefone.getText().replaceAll("\\D", "");

        String email =
                campoEmail.getText();

        String senha =
                campoSenha.getText();

        String confirmarSenha =
                campoConfirmarSenha.getText();


        // ==============================
        // DADOS DO ENDEREÇO
        // ==============================

        String cep =
                campoCep.getText().replaceAll("\\D", "");

        Estado estadoSelecionado =
                campoEstado.getValue();

        String estado = "";
        String uf = "";

        if (estadoSelecionado != null) {

            estado = estadoSelecionado.getNome();
            uf = estadoSelecionado.getUf();
        }

        String cidade =
                campoCidade.getText();

        String bairro =
                campoBairro.getText();

        String rua =
                campoRua.getText();

        String numero =
                campoNumero.getText();

        String complemento =
                campoComplemento.getText();


        // ==============================
        // EXIBIR DADOS NO CONSOLE
        // ==============================

        System.out.println("Dados recebidos do formulário.");

        System.out.println("CNPJ: " + cnpj);
        System.out.println("Razão Social: " + razaoSocial);
        System.out.println("Telefone: " + telefone);
        System.out.println("Email: " + email);

        System.out.println("Endereço:");

        System.out.println("CEP: " + cep);
        System.out.println("Estado: " + estado);
        System.out.println("UF: " + uf);
        System.out.println("Cidade: " + cidade);
        System.out.println("Bairro: " + bairro);
        System.out.println("Rua: " + rua);
        System.out.println("Número: " + numero);
        System.out.println("Complemento: " + complemento);


        // ==============================
        // VALIDAÇÃO DOS CAMPOS
        // ==============================

        if (cnpj.isEmpty() ||
                razaoSocial.isEmpty() ||
                telefone.isEmpty() ||
                email.isEmpty() ||
                senha.isEmpty() ||
                confirmarSenha.isEmpty() ||
                cep.isEmpty() ||
                estado.isEmpty() ||
                cidade.isEmpty() ||
                bairro.isEmpty() ||
                rua.isEmpty() ||
                numero.isEmpty()) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Preencha todos os campos obrigatórios!",
                    "Atenção"
            );

            return;
        }


        // ==============================
        // VALIDAÇÃO DO CNPJ
        // ==============================

        if (cnpj.length() != 14) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Digite um CNPJ válido com 14 números!",
                    "CNPJ inválido"
            );

            return;
        }


        // ==============================
        // CNPJ DUPLICADO
        // ==============================

        if (SolicitanteDAO.cnpjExiste(cnpj)) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Este CNPJ já está cadastrado!",
                    "CNPJ já cadastrado"
            );

            return;
        }


        // ==============================
        // VALIDAÇÃO DO E-MAIL
        // ==============================

        if (!email.matches(
                "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Digite um e-mail válido!",
                    "E-mail inválido"
            );

            return;
        }


        // ==============================
        // VALIDAÇÃO DO TELEFONE
        // ==============================

        if (telefone.length() < 10 ||
                telefone.length() > 14) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Digite um telefone válido!",
                    "Telefone inválido"
            );

            return;
        }


        // ==============================
        // VALIDAÇÃO DO CEP
        // ==============================

        if (cep.length() != 8) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Digite um CEP válido com 8 números!",
                    "CEP inválido"
            );

            return;
        }


        // ==============================
        // VALIDAÇÃO DA SENHA
        // ==============================

        if (senha.length() < 6) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "A senha deve ter pelo menos 6 caracteres!",
                    "Senha inválida"
            );

            return;
        }


        // ==============================
        // CONFIRMAÇÃO DA SENHA
        // ==============================

        if (!senha.equals(confirmarSenha)) {

            mostrarAlerta(
                    Alert.AlertType.ERROR,
                    "As senhas não são iguais!",
                    "Erro"
            );

            return;
        }


        System.out.println("As senhas conferem.");


        // ==============================
        // CRIAR ENDEREÇO
        // ==============================

        Endereco endereco = new Endereco(
                cep,
                estado,
                uf,
                cidade,
                bairro,
                rua,
                numero,
                complemento
        );


        System.out.println(
                "Objeto Endereco criado."
        );


        // ==============================
        // SALVAR ENDEREÇO
        // ==============================

        System.out.println(
                "Salvando endereço no banco..."
        );

        int enderecoId =
                EnderecoDAO.salvar(endereco);


        System.out.println(
                "ID do endereço: " + enderecoId
        );


        // ==============================
        // VERIFICAR SE ENDEREÇO FOI SALVO
        // ==============================

        if (enderecoId == 0) {

            mostrarAlerta(
                    Alert.AlertType.ERROR,
                    "Não foi possível salvar o endereço.",
                    "Erro"
            );

            return;
        }


        // ==============================
        // CRIAR SOLICITANTE
        // ==============================

        Solicitante solicitante =
                new Solicitante(
                        cnpj,
                        razaoSocial,
                        telefone,
                        email,
                        senha,
                        endereco
                );


        System.out.println(
                "Objeto Solicitante criado."
        );


        // ==============================
        // SALVAR SOLICITANTE
        // ==============================

        System.out.println(
                "Salvando solicitante no banco..."
        );

        boolean salvo =
                SolicitanteDAO.salvar(
                        solicitante,
                        enderecoId
                );


        System.out.println(
                "Resultado do cadastro: " + salvo
        );


        // ==============================
        // CADASTRO REALIZADO
        // ==============================

        if (salvo) {

            System.out.println(
                    "Cadastro realizado com sucesso!"
            );

            mostrarAlerta(
                    Alert.AlertType.INFORMATION,
                    "Cadastro realizado com sucesso!",
                    "Cadastro"
            );


            try {

                Navegacao.trocarTela(
                        campoCnpj,
                        "/View/TelaInicial.fxml"
                );

            } catch (IOException e) {

                e.printStackTrace();
            }

        } else {

            System.out.println(
                    "Erro ao realizar o cadastro."
            );

            mostrarAlerta(
                    Alert.AlertType.ERROR,
                    "Não foi possível realizar o cadastro.",
                    "Erro"
            );
        }
    }


    // ==============================
    // MÉTODO PARA MOSTRAR ALERTAS
    // ==============================

    private void mostrarAlerta(
            Alert.AlertType tipo,
            String mensagem,
            String titulo) {

        Alert alerta = new Alert(
                tipo,
                mensagem,
                ButtonType.OK
        );

        alerta.setTitle(titulo);
        alerta.setHeaderText(null);

        DialogPane dialogPane =
                alerta.getDialogPane();

        dialogPane.setStyle(
                "-fx-background-color: #0B1F3A;"
        );

        dialogPane.lookupButton(
                ButtonType.OK
        ).setStyle(
                "-fx-background-color: #C62828;" +
                        "-fx-text-fill: white;" +
                        "-fx-font-weight: bold;"
        );

        dialogPane.lookup(
                ".content.label"
        ).setStyle(
                "-fx-text-fill: white;" +
                        "-fx-font-size: 14px;"
        );

        alerta.showAndWait();
    }


    // ==============================
    // VOLTAR
    // ==============================

    @FXML
    private void voltarTelaInicial(
            ActionEvent event) throws IOException {

        Navegacao.trocarTela(
                (Node) event.getSource(),
                "/View/EscolhaCadastro.fxml"
        );
    }
}