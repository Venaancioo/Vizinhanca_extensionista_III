package Controller;

import DAO.ConsultaVoluntarioDAO;
import DAO.GeneroDAO;
import Model.Genero;
import Model.Solicitante;
import Model.Voluntario;
import Util.Navegacao;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DialogPane;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.util.List;

public class PesquisaVoluntarioController {

    private Solicitante solicitante;

    @FXML
    private ComboBox<Genero> campoGenero;

    @FXML
    private TextField campoCidade;

    @FXML
    private ListView<String> listaVoluntarios;


    @FXML
    private void initialize() {

        campoGenero.getItems().addAll(
                GeneroDAO.listar()
        );
    }


    public void setSolicitante(Solicitante solicitante) {

        this.solicitante = solicitante;
    }


    @FXML
    private void pesquisar() {

        String cidade =
                campoCidade.getText().trim();

        Genero genero =
                campoGenero.getValue();


        if (cidade.isEmpty()) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Digite a cidade para realizar a pesquisa.",
                    "Atenção"
            );

            return;
        }


        if (genero == null) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Selecione o tipo de serviço.",
                    "Atenção"
            );

            return;
        }


        List<Voluntario> voluntarios =
                ConsultaVoluntarioDAO.buscarPorGeneroECidade(
                        genero.getCodigo(),
                        cidade
                );


        listaVoluntarios.getItems().clear();


        if (voluntarios.isEmpty()) {

            listaVoluntarios.getItems().add(
                    "Nenhum voluntário encontrado para os filtros informados."
            );

            return;
        }


        for (Voluntario voluntario : voluntarios) {

            String endereco =
                    voluntario.getEndereco() != null
                            ? voluntario.getEndereco().getBairro()
                            + ", "
                            + voluntario.getEndereco().getCidade()
                            + " "
                            + voluntario.getEndereco().getUf()
                            : "Localização não informada";


            String resultado =
                    "Nome: "
                            + voluntario.getNomeCompleto()

                            + "\nTelefone: "
                            + voluntario.getTelefone()

                            + "\nE-mail: "
                            + voluntario.getEmail()

                            + "\nHabilidades: "
                            + voluntario.getHabilidades()

                            + "\nEndereço: "
                            + endereco;


            listaVoluntarios.getItems().add(
                    resultado
            );
        }
    }


    private void mostrarAlerta(
            Alert.AlertType tipo,
            String mensagem,
            String titulo
    ) {

        Alert alerta =
                new Alert(
                        tipo,
                        mensagem,
                        ButtonType.OK
                );

        alerta.setTitle(titulo);
        alerta.setHeaderText(null);


        DialogPane dialogPane =
                alerta.getDialogPane();

        dialogPane.setStyle(
                "-fx-background-color: #0B1F3A;"
        );


        dialogPane
                .lookupButton(ButtonType.OK)
                .setStyle(
                        "-fx-background-color: #C62828;"
                                + "-fx-text-fill: white;"
                                + "-fx-font-weight: bold;"
                );


        if (dialogPane.lookup(".content.label") != null) {

            dialogPane
                    .lookup(".content.label")
                    .setStyle(
                            "-fx-text-fill: white;"
                                    + "-fx-font-size: 14px;"
                    );
        }


        alerta.showAndWait();
    }


    @FXML
    private void voltarMenu(
            ActionEvent event
    ) throws IOException {

        if (solicitante != null) {

            Navegacao.trocarTela(
                    (Node) event.getSource(),
                    "/View/MenuSolicitante.fxml",
                    solicitante
            );

        } else {

            Navegacao.trocarTela(
                    (Node) event.getSource(),
                    "/View/TelaInicial.fxml"
            );
        }
    }
}