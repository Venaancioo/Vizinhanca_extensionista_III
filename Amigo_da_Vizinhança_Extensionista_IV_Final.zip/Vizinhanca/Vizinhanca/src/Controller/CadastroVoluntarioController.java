package Controller;

import DAO.EnderecoDAO;
import DAO.EstadoDAO;
import DAO.GeneroDAO;
import DAO.VoluntarioDAO;
import Model.Endereco;
import Model.Estado;
import Model.Genero;
import Model.Voluntario;
import Util.Navegacao;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DialogPane;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.io.IOException;

public class CadastroVoluntarioController {

    @FXML
    private TextField campoCpf;

    @FXML
    private TextField campoNome;

    @FXML
    private TextField campoTelefone;

    @FXML
    private TextField campoEmail;

    @FXML
    private PasswordField campoSenha;

    @FXML
    private PasswordField campoConfirmarSenha;

    @FXML
    private ComboBox<Genero> campoGenero;

    @FXML
    private TextArea campoHabilidades;

    @FXML
    private TextField campoCep;

    @FXML
    private ComboBox<Estado> campoEstado;

    @FXML
    private TextField campoCidade;

    @FXML
    private TextField campoBairro;

    @FXML
    private TextField campoRua;

    @FXML
    private TextField campoNumero;

    @FXML
    private TextField campoComplemento;


    @FXML
    private void initialize() {

        campoGenero.getItems().addAll(
                GeneroDAO.listar()
        );

        campoEstado.getItems().addAll(
                EstadoDAO.listarTodos()
        );
    }


    @FXML
    private void cadastrar() {

        String cpf =
                campoCpf.getText()
                        .replaceAll("\\D", "");

        String nome =
                campoNome.getText().trim();

        String telefone =
                campoTelefone.getText()
                        .replaceAll("\\D", "");

        String email =
                campoEmail.getText().trim();

        String senha =
                campoSenha.getText();

        String confirmarSenha =
                campoConfirmarSenha.getText();

        Genero generoSelecionado =
                campoGenero.getValue();

        String habilidades =
                campoHabilidades.getText().trim();

        String cep =
                campoCep.getText()
                        .replaceAll("\\D", "");

        Estado estadoSelecionado =
                campoEstado.getValue();

        String cidade =
                campoCidade.getText().trim();

        String bairro =
                campoBairro.getText().trim();

        String rua =
                campoRua.getText().trim();

        String numero =
                campoNumero.getText().trim();

        String complemento =
                campoComplemento.getText().trim();


        if (cpf.isEmpty() ||
                nome.isEmpty() ||
                telefone.isEmpty() ||
                email.isEmpty() ||
                senha.isEmpty() ||
                confirmarSenha.isEmpty() ||
                generoSelecionado == null ||
                habilidades.isEmpty() ||
                cep.isEmpty() ||
                estadoSelecionado == null ||
                cidade.isEmpty() ||
                bairro.isEmpty() ||
                rua.isEmpty() ||
                numero.isEmpty()) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Preencha todos os campos obrigatórios!",
                    "Atenção"
            );

            return;
        }


        if (cpf.length() != 11) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Digite um CPF válido com 11 números!",
                    "CPF inválido"
            );

            return;
        }


        if (VoluntarioDAO.cpfExiste(cpf)) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Este CPF já está cadastrado!",
                    "CPF já cadastrado"
            );

            return;
        }


        if (!email.matches(
                "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Digite um e-mail válido!",
                    "E-mail inválido"
            );

            return;
        }


        if (VoluntarioDAO.emailExiste(email)) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Este e-mail já está cadastrado!",
                    "E-mail já cadastrado"
            );

            return;
        }


        if (telefone.length() < 10 ||
                telefone.length() > 14) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Digite um telefone válido!",
                    "Telefone inválido"
            );

            return;
        }


        if (cep.length() != 8) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Digite um CEP válido com 8 números!",
                    "CEP inválido"
            );

            return;
        }


        if (senha.length() < 6) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "A senha deve ter pelo menos 6 caracteres!",
                    "Senha inválida"
            );

            return;
        }


        if (!senha.equals(confirmarSenha)) {

            mostrarAlerta(
                    Alert.AlertType.ERROR,
                    "As senhas não são iguais!",
                    "Erro"
            );

            return;
        }


        String estado =
                estadoSelecionado.getNome();

        String uf =
                estadoSelecionado.getUf();


        Endereco endereco = new Endereco(
                cep,
                estado,
                uf,
                cidade,
                bairro,
                rua,
                numero,
                complemento
        );


        int enderecoId =
                EnderecoDAO.salvar(endereco);


        if (enderecoId == 0) {

            mostrarAlerta(
                    Alert.AlertType.ERROR,
                    "Não foi possível salvar o endereço.",
                    "Erro"
            );

            return;
        }


        endereco.setId(enderecoId);


        Voluntario voluntario =
                new Voluntario(
                        cpf,
                        nome,
                        telefone,
                        email,
                        senha,
                        habilidades,
                        generoSelecionado,
                        endereco
                );


        boolean salvo =
                VoluntarioDAO.salvar(
                        voluntario
                );


        if (salvo) {

            mostrarAlerta(
                    Alert.AlertType.INFORMATION,
                    "Cadastro realizado com sucesso!",
                    "Cadastro"
            );

            try {

                Navegacao.trocarTela(
                        campoCpf,
                        "/View/TelaInicial.fxml"
                );

            } catch (IOException e) {

                e.printStackTrace();
            }

        } else {

            mostrarAlerta(
                    Alert.AlertType.ERROR,
                    "Não foi possível realizar o cadastro.",
                    "Erro"
            );
        }
    }


    private void mostrarAlerta(
            Alert.AlertType tipo,
            String mensagem,
            String titulo
    ) {

        Alert alerta = new Alert(
                tipo,
                mensagem,
                ButtonType.OK
        );

        alerta.setTitle(titulo);
        alerta.setHeaderText(null);

        DialogPane dialogPane =
                alerta.getDialogPane();

        dialogPane.setStyle(
                "-fx-background-color: #0B1F3A;"
        );

        dialogPane.lookupButton(
                ButtonType.OK
        ).setStyle(
                "-fx-background-color: #C62828;" +
                        "-fx-text-fill: white;" +
                        "-fx-font-weight: bold;"
        );

        if (dialogPane.lookup(
                ".content.label"
        ) != null) {

            dialogPane.lookup(
                    ".content.label"
            ).setStyle(
                    "-fx-text-fill: white;" +
                            "-fx-font-size: 14px;"
            );
        }

        alerta.showAndWait();
    }


    @FXML
    private void voltarTelaInicial(
            ActionEvent event
    ) throws IOException {

        Navegacao.trocarTela(
                (Node) event.getSource(),
                "/View/EscolhaCadastro.fxml"
        );
    }
}