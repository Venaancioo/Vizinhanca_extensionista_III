package Controller;

import DAO.ConsultaVoluntarioDAO;
import Model.Voluntario;
import Util.Navegacao;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DialogPane;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.IOException;

public class LoginVoluntarioController {

    @FXML
    private TextField campoEmail;

    @FXML
    private PasswordField campoSenha;

    @FXML
    private void entrar(ActionEvent event) {

        String email = campoEmail.getText().trim();
        String senha = campoSenha.getText();

        if (email.isEmpty() || senha.isEmpty()) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Preencha o e-mail e a senha!",
                    "Atenção"
            );

            return;
        }

        Voluntario voluntario =
                ConsultaVoluntarioDAO.buscarLogin(
                        email,
                        senha
                );

        if (voluntario == null) {

            mostrarAlerta(
                    Alert.AlertType.ERROR,
                    "E-mail ou senha incorretos!",
                    "Login inválido"
            );

            return;
        }

        try {

            Navegacao.trocarTela(
                    (Node) event.getSource(),
                    "/View/MenuVoluntario.fxml",
                    voluntario
            );

        } catch (IOException e) {

            e.printStackTrace();

            mostrarAlerta(
                    Alert.AlertType.ERROR,
                    "Não foi possível abrir o menu.",
                    "Erro"
            );
        }
    }


    private void mostrarAlerta(
            Alert.AlertType tipo,
            String mensagem,
            String titulo
    ) {

        Alert alerta = new Alert(
                tipo,
                mensagem,
                ButtonType.OK
        );

        alerta.setTitle(titulo);
        alerta.setHeaderText(null);

        DialogPane dialogPane =
                alerta.getDialogPane();

        dialogPane.setStyle(
                "-fx-background-color: #0B1F3A;"
        );

        dialogPane.lookupButton(
                ButtonType.OK
        ).setStyle(
                "-fx-background-color: #C62828;" +
                        "-fx-text-fill: white;" +
                        "-fx-font-weight: bold;"
        );

        if (dialogPane.lookup(
                ".content.label"
        ) != null) {

            dialogPane.lookup(
                    ".content.label"
            ).setStyle(
                    "-fx-text-fill: white;" +
                            "-fx-font-size: 14px;"
            );
        }

        alerta.showAndWait();
    }


    @FXML
    private void voltarTelaInicial(
            ActionEvent event
    ) throws IOException {

        Navegacao.trocarTela(
                (Node) event.getSource(),
                "/View/TelaInicial.fxml"
        );
    }
}