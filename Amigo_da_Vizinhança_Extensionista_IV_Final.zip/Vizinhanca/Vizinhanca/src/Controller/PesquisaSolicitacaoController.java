package Controller;

import DAO.ConsultaSolicitacaoDAO;
import DAO.GeneroDAO;
import Model.Genero;
import Model.Solicitacao;
import Model.Voluntario;
import Util.Navegacao;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DialogPane;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.util.List;

public class PesquisaSolicitacaoController {

    private Voluntario voluntario;

    @FXML
    private ComboBox<Genero> campoGenero;

    @FXML
    private TextField campoCidade;

    @FXML
    private ListView<String> listaSolicitacoes;


    @FXML
    private void initialize() {

        campoGenero.getItems().addAll(
                GeneroDAO.listar()
        );
    }


    public void setVoluntario(Voluntario voluntario) {

        this.voluntario = voluntario;
    }


    @FXML
    private void pesquisar() {

        String cidade =
                campoCidade.getText().trim();

        Genero genero =
                campoGenero.getValue();


        if (cidade.isEmpty()) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Digite a cidade para realizar a pesquisa.",
                    "Atenção"
            );

            return;
        }


        if (genero == null) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Selecione o tipo de serviço.",
                    "Atenção"
            );

            return;
        }


        List<Solicitacao> solicitacoes =
                ConsultaSolicitacaoDAO.buscarPorGeneroECidade(
                        genero.getCodigo(),
                        cidade
                );


        listaSolicitacoes.getItems().clear();


        if (solicitacoes.isEmpty()) {

            listaSolicitacoes.getItems().add(
                    "Nenhuma solicitação encontrada para os filtros informados."
            );

            return;
        }


        for (Solicitacao solicitacao : solicitacoes) {

            String endereco =
                    "Endereço não informado";


            if (solicitacao.getEndereco() != null) {

                endereco =
                        solicitacao.getEndereco().getRua()
                                + ", "
                                + solicitacao.getEndereco().getNumero()
                                + " - "
                                + solicitacao.getEndereco().getBairro()
                                + ", "
                                + solicitacao.getEndereco().getCidade()
                                + "/"
                                + solicitacao.getEndereco().getUf();
            }


            String solicitante =
                    "Solicitante não informado";


            String telefone =
                    "Não informado";


            String email =
                    "Não informado";


            if (solicitacao.getSolicitante() != null) {

                solicitante =
                        solicitacao.getSolicitante()
                                .getRazaoSocial();

                telefone =
                        solicitacao.getSolicitante()
                                .getTelefone();

                email =
                        solicitacao.getSolicitante()
                                .getEmail();
            }


            String resultado =
                    "Solicitação #"
                            + solicitacao.getId()

                            + "\nTipo de serviço: "
                            + solicitacao.getGenero().getNome()

                            + "\nDescrição: "
                            + solicitacao.getDescricao()

                            + "\nSolicitante: "
                            + solicitante

                            + "\nTelefone: "
                            + telefone

                            + "\nE-mail: "
                            + email

                            + "\nEndereço: "
                            + endereco;


            listaSolicitacoes.getItems().add(
                    resultado
            );
        }
    }


    private void mostrarAlerta(
            Alert.AlertType tipo,
            String mensagem,
            String titulo
    ) {

        Alert alerta =
                new Alert(
                        tipo,
                        mensagem,
                        ButtonType.OK
                );

        alerta.setTitle(titulo);
        alerta.setHeaderText(null);


        DialogPane dialogPane =
                alerta.getDialogPane();

        dialogPane.setStyle(
                "-fx-background-color: #0B1F3A;"
        );


        dialogPane
                .lookupButton(ButtonType.OK)
                .setStyle(
                        "-fx-background-color: #C62828;"
                                + "-fx-text-fill: white;"
                                + "-fx-font-weight: bold;"
                );


        if (dialogPane.lookup(".content.label") != null) {

            dialogPane
                    .lookup(".content.label")
                    .setStyle(
                            "-fx-text-fill: white;"
                                    + "-fx-font-size: 14px;"
                    );
        }


        alerta.showAndWait();
    }


    @FXML
    private void voltarMenu(
            ActionEvent event
    ) throws IOException {

        if (voluntario != null) {

            Navegacao.trocarTela(
                    (Node) event.getSource(),
                    "/View/MenuVoluntario.fxml",
                    voluntario
            );

        } else {

            Navegacao.trocarTela(
                    (Node) event.getSource(),
                    "/View/TelaInicial.fxml"
            );
        }
    }
}