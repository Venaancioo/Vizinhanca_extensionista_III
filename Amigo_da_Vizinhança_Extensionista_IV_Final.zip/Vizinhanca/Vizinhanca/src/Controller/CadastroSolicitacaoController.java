package Controller;

import DAO.EnderecoDAO;
import DAO.EstadoDAO;
import DAO.GeneroDAO;
import DAO.SolicitacaoDAO;
import Model.Endereco;
import Model.Estado;
import Model.Genero;
import Model.Solicitante;
import Model.Solicitacao;
import Util.Navegacao;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DialogPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.io.IOException;

public class CadastroSolicitacaoController {

    private Solicitante solicitante;

    @FXML
    private ComboBox<Genero> campoGenero;

    @FXML
    private TextArea campoDescricao;

    @FXML
    private TextField campoCep;

    @FXML
    private ComboBox<Estado> campoEstado;

    @FXML
    private TextField campoCidade;

    @FXML
    private TextField campoBairro;

    @FXML
    private TextField campoRua;

    @FXML
    private TextField campoNumero;

    @FXML
    private TextField campoComplemento;


    @FXML
    private void initialize() {

        campoGenero.getItems().addAll(
                GeneroDAO.listar()
        );

        campoEstado.getItems().addAll(
                EstadoDAO.listarTodos()
        );
    }


    public void setSolicitante(Solicitante solicitante) {
        this.solicitante = solicitante;
    }


    @FXML
    private void cadastrar() {

        if (solicitante == null) {

            mostrarAlerta(
                    Alert.AlertType.ERROR,
                    "Não foi possível identificar o solicitante logado.",
                    "Erro"
            );

            return;
        }


        Genero genero =
                campoGenero.getValue();

        String descricao =
                campoDescricao.getText().trim();

        String cep =
                campoCep.getText()
                        .replaceAll("\\D", "");

        Estado estadoSelecionado =
                campoEstado.getValue();

        String cidade =
                campoCidade.getText().trim();

        String bairro =
                campoBairro.getText().trim();

        String rua =
                campoRua.getText().trim();

        String numero =
                campoNumero.getText().trim();

        String complemento =
                campoComplemento.getText().trim();


        if (genero == null ||
                descricao.isEmpty() ||
                cep.isEmpty() ||
                estadoSelecionado == null ||
                cidade.isEmpty() ||
                bairro.isEmpty() ||
                rua.isEmpty() ||
                numero.isEmpty()) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Preencha todos os campos obrigatórios!",
                    "Atenção"
            );

            return;
        }


        if (descricao.length() < 10) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Descreva a solicitação com pelo menos 10 caracteres.",
                    "Descrição inválida"
            );

            return;
        }


        if (cep.length() != 8) {

            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Digite um CEP válido com 8 números!",
                    "CEP inválido"
            );

            return;
        }


        String estado =
                estadoSelecionado.getNome();

        String uf =
                estadoSelecionado.getUf();


        Endereco endereco =
                new Endereco(
                        cep,
                        estado,
                        uf,
                        cidade,
                        bairro,
                        rua,
                        numero,
                        complemento
                );


        int enderecoId =
                EnderecoDAO.salvar(endereco);


        if (enderecoId == 0) {

            mostrarAlerta(
                    Alert.AlertType.ERROR,
                    "Não foi possível salvar o endereço.",
                    "Erro"
            );

            return;
        }


        endereco.setId(enderecoId);


        Solicitacao solicitacao =
                new Solicitacao(
                        0,
                        genero,
                        descricao,
                        endereco,
                        solicitante
                );


        boolean salvo =
                SolicitacaoDAO.salvar(
                        solicitacao
                );


        if (salvo) {

            mostrarAlerta(
                    Alert.AlertType.INFORMATION,
                    "Solicitação cadastrada com sucesso!",
                    "Sucesso"
            );

            try {

                Navegacao.trocarTela(
                        campoGenero,
                        "/View/MenuSolicitante.fxml",
                        solicitante
                );

            } catch (IOException e) {

                e.printStackTrace();

                mostrarAlerta(
                        Alert.AlertType.ERROR,
                        "A solicitação foi salva, mas não foi possível voltar ao menu.",
                        "Erro"
                );
            }

        } else {

            mostrarAlerta(
                    Alert.AlertType.ERROR,
                    "Não foi possível cadastrar a solicitação.",
                    "Erro"
            );
        }
    }


    private void mostrarAlerta(
            Alert.AlertType tipo,
            String mensagem,
            String titulo
    ) {

        Alert alerta =
                new Alert(
                        tipo,
                        mensagem,
                        ButtonType.OK
                );

        alerta.setTitle(titulo);
        alerta.setHeaderText(null);

        DialogPane dialogPane =
                alerta.getDialogPane();

        dialogPane.setStyle(
                "-fx-background-color: #0B1F3A;"
        );

        dialogPane.lookupButton(
                ButtonType.OK
        ).setStyle(
                "-fx-background-color: #C62828;" +
                        "-fx-text-fill: white;" +
                        "-fx-font-weight: bold;"
        );

        if (dialogPane.lookup(
                ".content.label"
        ) != null) {

            dialogPane.lookup(
                    ".content.label"
            ).setStyle(
                    "-fx-text-fill: white;" +
                            "-fx-font-size: 14px;"
            );
        }

        alerta.showAndWait();
    }


    @FXML
    private void voltarMenu(
            ActionEvent event
    ) throws IOException {

        if (solicitante != null) {

            Navegacao.trocarTela(
                    (Node) event.getSource(),
                    "/View/MenuSolicitante.fxml",
                    solicitante
            );

        } else {

            Navegacao.trocarTela(
                    (Node) event.getSource(),
                    "/View/TelaInicial.fxml"
            );
        }
    }
}