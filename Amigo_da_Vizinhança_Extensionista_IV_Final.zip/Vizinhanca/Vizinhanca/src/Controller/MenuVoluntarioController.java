package Controller;

import Model.Voluntario;
import Util.Navegacao;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;

import java.io.IOException;

public class MenuVoluntarioController {

    private Voluntario voluntario;

    public void setVoluntario(Voluntario voluntario) {
        this.voluntario = voluntario;
    }

    @FXML
    private void abrirPesquisaSolicitacao(ActionEvent event) throws IOException {

        if (voluntario == null) {
            Navegacao.trocarTela(
                    (Node) event.getSource(),
                    "/View/TelaInicial.fxml"
            );
            return;
        }

        Navegacao.trocarTela(
                (Node) event.getSource(),
                "/View/PesquisaSolicitacao.fxml",
                voluntario
        );
    }

    @FXML
    private void voltarTelaInicial(ActionEvent event) throws IOException {
        Navegacao.trocarTela(
                (Node) event.getSource(),
                "/View/TelaInicial.fxml"
        );
    }
}