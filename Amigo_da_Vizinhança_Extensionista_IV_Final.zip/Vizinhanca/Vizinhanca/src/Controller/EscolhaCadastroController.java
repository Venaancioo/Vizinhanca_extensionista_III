package Controller;

import Util.Navegacao;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;

import java.io.IOException;

public class EscolhaCadastroController {

    @FXML
    private void abrirCadastroSolicitante(ActionEvent event) throws IOException {

        Navegacao.trocarTela(
                (Node) event.getSource(),
                "/View/CadastroSolicitante.fxml"
        );
    }

    @FXML
    private void abrirCadastroVoluntario(ActionEvent event) throws IOException {

        Navegacao.trocarTela(
                (Node) event.getSource(),
                "/View/CadastroVoluntario.fxml"
        );
    }

    @FXML
    private void voltarTelaInicial(ActionEvent event) throws IOException {

        Navegacao.trocarTela(
                (Node) event.getSource(),
                "/View/TelaInicial.fxml"
        );
    }
}