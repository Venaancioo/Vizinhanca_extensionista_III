package Controller;

import Model.Solicitante;
import Util.Navegacao;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;

import java.io.IOException;

public class MenuSolicitanteController {

    private Solicitante solicitante;


    public void setSolicitante(Solicitante solicitante) {

        this.solicitante = solicitante;
    }


    @FXML
    private void abrirNovaSolicitacao(
            ActionEvent event
    ) throws IOException {

        if (solicitante == null) {
            return;
        }

        Navegacao.trocarTela(
                (Node) event.getSource(),
                "/View/CadastroSolicitacao.fxml",
                solicitante
        );
    }


    @FXML
    private void abrirPesquisaVoluntario(
            ActionEvent event
    ) throws IOException {

        Navegacao.trocarTela(
                (Node) event.getSource(),
                "/View/PesquisaVoluntario.fxml",
                solicitante
        );
    }


    @FXML
    private void voltarTelaInicial(
            ActionEvent event
    ) throws IOException {

        Navegacao.trocarTela(
                (Node) event.getSource(),
                "/View/TelaInicial.fxml"
        );
    }
}