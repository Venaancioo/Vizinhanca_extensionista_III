package Conexao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class TesteBanco {

    public static void main(String[] args) {

        try {
            Connection conexao = Conexao.conectar();

            Statement comando = conexao.createStatement();

            ResultSet resultado = comando.executeQuery(
                    "SELECT * FROM genero"
            );

            while(resultado.next()) {

                System.out.println(
                        resultado.getInt("id")
                                + " - " +
                                resultado.getString("tipo_servico")
                );
            }

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}