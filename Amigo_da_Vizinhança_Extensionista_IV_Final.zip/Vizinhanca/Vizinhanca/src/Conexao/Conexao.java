package Conexao;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexao {
    private static final String URL =
            "jdbc:mysql://localhost:3306/sistema_vizinhanca";

    private static final String USUARIO = "root";
    private static final String SENHA = "1234";

    public static Connection conectar() {
        try {
            Connection conexao = DriverManager.getConnection(
                    URL,
                    USUARIO,
                    SENHA
            );

            System.out.println("Conectado ao banco com sucesso!");

            return conexao;

        } catch (Exception e) {

            System.out.println("Erro ao conectar:");
            e.printStackTrace();

            return null;
        }
    }
}