package Conexao;

import java.sql.Connection;

public class TesteConexao {

    public static void main(String[] args) {
       Connection conexao = Conexao.conectar();
    }
}