package Model;

public class Voluntario {
    private String cpf;
    private String nomeCompleto;
    private String telefone;
    private String email;
    private String senha;
    private String habilidades;
    private Endereco endereco;
    private Genero genero;

    public Voluntario(String cpf, String nomeCompleto, String telefone, String email, String senha, String habilidades, Genero genero, Endereco endereco) {
        this.cpf = cpf;
        this.nomeCompleto = nomeCompleto;
        this.telefone = telefone;
        this.email = email;
        this.senha = senha;
        this.habilidades = habilidades;
        this.genero = genero;
        this.endereco = endereco;
    }

    public void exibir() {
        System.out.println("Voluntário: " + nomeCompleto + " | CPF: " + cpf +
                " | Email: " + email + " | Telefone: " + telefone +
                " | Gênero: " + genero + " | Habilidades: " + habilidades);
        endereco.exibir();
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public String getCpf() {
        return cpf;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getNomeCompleto() {
        return nomeCompleto;
    }

    public String getEmail() {
        return email;
    }

    public String getSenha() {
        return senha;
    }

    public String getHabilidades() {
        return habilidades;
    }

    public Genero getGenero() { return genero;  }
}