package Model;

public class Endereco {

    private int id;
    private String cep;
    private String estado;
    private String uf;
    private String cidade;
    private String bairro;
    private String rua;
    private String numero;
    private String complemento;

    public Endereco(
            String cep,
            String estado,
            String uf,
            String cidade,
            String bairro,
            String rua,
            String numero,
            String complemento) {

        this.cep = cep;
        this.estado = estado;
        this.uf = uf;
        this.cidade = cidade;
        this.bairro = bairro;
        this.rua = rua;
        this.numero = numero;
        this.complemento = complemento;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getCep() {
        return cep;
    }

    public String getEstado() {
        return estado;
    }

    public String getUf() {
        return uf;
    }

    public String getCidade() {
        return cidade;
    }

    public String getBairro() {
        return bairro;
    }

    public String getRua() {
        return rua;
    }

    public String getNumero() {
        return numero;
    }

    public String getComplemento() {
        return complemento;
    }

    public void exibir() {

        System.out.println(
                "Endereço: " +
                        rua + ", " +
                        numero +
                        " - " +
                        bairro +
                        ", " +
                        cidade +
                        "/" +
                        uf +
                        " CEP: " +
                        cep +
                        " Complemento: " +
                        complemento
        );
    }
}