package Model;

public class Solicitante {
    private int id;
    private String cnpj;
    private String razaoSocial;
    private String telefone;
    private String email;
    private String senha;
    private Endereco endereco;

    public Solicitante(String cnpj, String razaoSocial, String telefone, String email, String senha, Endereco endereco) {
        this.cnpj = cnpj;
        this.razaoSocial = razaoSocial;
        this.telefone = telefone;
        this.email = email;
        this.senha = senha;
        this.endereco = endereco;
    }

    public void exibir() {
        System.out.println("Model.Solicitante: " + razaoSocial + " | CNPJ: " + cnpj +
                " | Email: " + email + " | Telefone: " + telefone);

        if (endereco != null) {
            endereco.exibir();
        }
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public String getCnpj() {
        return cnpj;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getEmail() {
        return email;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSenha() {
        return senha;
    }
}