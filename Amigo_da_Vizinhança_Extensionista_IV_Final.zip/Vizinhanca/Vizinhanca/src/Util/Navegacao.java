package Util;

import Controller.CadastroSolicitacaoController;
import Controller.MenuSolicitanteController;
import Controller.MenuVoluntarioController;
import Controller.PesquisaSolicitacaoController;
import Controller.PesquisaVoluntarioController;
import Model.Solicitante;
import Model.Voluntario;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class Navegacao {

    public static void trocarTela(
            Node elemento,
            String caminhoFXML
    ) throws IOException {

        FXMLLoader loader = new FXMLLoader(
                Navegacao.class.getResource(caminhoFXML)
        );

        Scene scene = new Scene(loader.load());

        Stage stage =
                (Stage) elemento.getScene().getWindow();

        stage.setScene(scene);
        stage.show();
    }


    public static void trocarTela(
            Node elemento,
            String caminhoFXML,
            Object objeto
    ) throws IOException {

        FXMLLoader loader = new FXMLLoader(
                Navegacao.class.getResource(caminhoFXML)
        );

        Scene scene = new Scene(loader.load());

        Object controller = loader.getController();

        if (controller instanceof MenuSolicitanteController
                && objeto instanceof Solicitante) {

            MenuSolicitanteController menu =
                    (MenuSolicitanteController) controller;

            menu.setSolicitante(
                    (Solicitante) objeto
            );
        }

        else if (controller instanceof MenuVoluntarioController
                && objeto instanceof Voluntario) {

            MenuVoluntarioController menu =
                    (MenuVoluntarioController) controller;

            menu.setVoluntario(
                    (Voluntario) objeto
            );
        }

        else if (controller instanceof CadastroSolicitacaoController
                && objeto instanceof Solicitante) {

            CadastroSolicitacaoController cadastro =
                    (CadastroSolicitacaoController) controller;

            cadastro.setSolicitante(
                    (Solicitante) objeto
            );
        }

        else if (controller instanceof PesquisaVoluntarioController
                && objeto instanceof Solicitante) {

            PesquisaVoluntarioController pesquisa =
                    (PesquisaVoluntarioController) controller;

            pesquisa.setSolicitante(
                    (Solicitante) objeto
            );
        }

        else if (controller instanceof PesquisaSolicitacaoController
                && objeto instanceof Voluntario) {

            PesquisaSolicitacaoController pesquisa =
                    (PesquisaSolicitacaoController) controller;

            pesquisa.setVoluntario(
                    (Voluntario) objeto
            );
        }


        Stage stage =
                (Stage) elemento.getScene().getWindow();

        stage.setScene(scene);
        stage.show();
    }
}