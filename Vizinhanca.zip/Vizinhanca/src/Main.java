public class Main {
    public static void main(String[] args) {
    Sistema sistema = new Sistema();
    sistema.executar();
    }
}
