import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Sistema {
    private Scanner scanner;
    private List<Solicitante> solicitantes;
    private List<Voluntario> voluntarios;
    private List<Solicitacao> solicitacoes;
    private int contadorSolicitacoes = 1;

    public Sistema() {
        this.solicitantes = new ArrayList<>();
        this.voluntarios = new ArrayList<>();
        this.solicitacoes = new ArrayList<>();
        this.scanner = new Scanner(System.in);
    }

    public void executar() {
        int opcao;
        do {
            System.out.println("""
                    
                    Digite o número da opção desejada:
                    1 - Cadastrar solicitante
                    2 - Entrar solicitante
                    3 - Cadastrar voluntário
                    4 - Entrar voluntário
                    0 - Sair
                    """);

            opcao = Integer.parseInt(scanner.nextLine());

            switch (opcao) {
                case 1 -> cadastrarSolicitante();
                case 2 -> entrarSolicitante();
                case 3 -> cadastrarVoluntario();
                case 4 -> entrarVoluntario();
                case 0 -> System.out.println("Saindo...");
                default -> System.out.println("Opção inválida, tente novamente!");
            }
        } while (opcao != 0);
    }

    public void cadastrarSolicitante() {
        System.out.println("Digite o CNPJ: ");
        String cnpj = scanner.nextLine();

        System.out.println("Digite a Razão Social: ");
        String razao = scanner.nextLine();

        System.out.println("Digite o telefone: ");
        String tel = scanner.nextLine();

        System.out.println("Digite o email: ");
        String email = scanner.nextLine();

        String senha;
        String confirmaSenha;

        do {
            System.out.println("Digite a senha: ");
            senha = scanner.nextLine();

            System.out.println("Confirmar senha: ");
            confirmaSenha = scanner.nextLine();

            if(!senha.equals(confirmaSenha)) {
                System.out.println("As senhas não coincidem. Tente novamente!");
            }
        } while (!senha.equals(confirmaSenha));

        Endereco end = criarEndereco();

        Solicitante solicitante = new Solicitante(cnpj, razao, tel, email, senha, end);
        solicitantes.add(solicitante);

        System.out.println("Solicitante cadastrado com sucesso!");
    }

    private void entrarSolicitante(){
        int opcao;
        do {
            System.out.println("""
                    1 - Cadastrar solicitação
                    2 - Pesquisa voluntário por cidade
                    0 - Menu anterior
                    """);

            opcao = Integer.parseInt(scanner.nextLine());

            switch (opcao) {
                case 1 -> cadastrarSolicitacao();
                case 2 -> pesquisaVoluntario();
                case 0 -> System.out.println("Voltando ao menu anterior...");
            }
        } while (opcao != 0 );
    }

    public void cadastrarSolicitacao() {
        if (solicitantes.isEmpty()) {
            System.out.println("Não há solicitantes cadastrados.");
            return;
        }

        System.out.println("Escolha o solicitante pelo índice:");
        for (int i = 0; i < solicitantes.size(); i++) {
            System.out.print(i + " - ");
            solicitantes.get(i).exibir();
        }
        int indice = Integer.parseInt(scanner.nextLine());

        Solicitante solicitante = solicitantes.get(indice);

        System.out.println("Digite o gênero do serviço: ");
        String genero = scanner.nextLine();

        System.out.println("Digite a descrição do serviço: ");
        String desc = scanner.nextLine();

        System.out.println("Digire o endereço que o serviço será realizado");
        Endereco end = criarEndereco();

        Solicitacao solic = new Solicitacao(contadorSolicitacoes++, genero, desc, end, solicitante);
        solicitacoes.add(solic);

        System.out.println("Solicitação cadastrada com sucesso!");
    }

    private void pesquisaVoluntario() {
        System.out.println("Digite a cidade para buscar voluntários: ");
        String cidade = scanner.nextLine();

        boolean encontrado = false;
        for (Voluntario v : voluntarios) {
            if (v.getEndereco().getCidade().equalsIgnoreCase(cidade)) {
                v.exibir();
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("Nenhum voluntário encontrado nessa cidade.");
        }
    }

    private void cadastrarVoluntario() {
        System.out.println("Digite o CPF: ");
        String cpf = scanner.nextLine();

        System.out.println("Digite o nome completo: ");
        String nome = scanner.nextLine();

        System.out.println("Digite o telefone: ");
        String tel = scanner.nextLine();

        System.out.println("Digite o email: ");
        String email = scanner.nextLine();

        String senha;
        String confirmaSenha;

        do {
            System.out.println("Digite a senha: ");
            senha = scanner.nextLine();

            System.out.println("Confirmar senha: ");
            confirmaSenha = scanner.nextLine();

            if(!senha.equals(confirmaSenha)) {
                System.out.println("As senhas não coincidem. Tente novamente!");
            }
        } while (!senha.equals(confirmaSenha));

        System.out.println("Diga as suas habilidades: ");
        String hab = scanner.nextLine();

        Endereco end = criarEndereco();

        Voluntario voluntario = new Voluntario(cpf, nome, tel, email, senha, hab, end);
        voluntarios.add(voluntario);

        System.out.println("Voluntário cadastrado com sucesso!");
    }

    public void entrarVoluntario(){
        int opcao;
        do {
            System.out.println("""
                             1 - Pesquisar solicitação por cidade
                             0 - Menu anterior
                             """);

            opcao = Integer.parseInt(scanner.nextLine());

            switch (opcao) {
                case 1 -> pesquisaSolicitacao();
                case 0 -> System.out.println("Voltando ao menu anterior...");
            }
        } while (opcao != 0);
    }

    public void pesquisaSolicitacao(){
        System.out.println("Digite a cidade: ");
        String cidade = scanner.nextLine();

        boolean encontrado = false;
        for (Solicitacao s : solicitacoes) {
            if (s.getEndereco().getCidade().equalsIgnoreCase(cidade)) {
                s.exibir();
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("Nenhuma solicitação encontrada nessa cidade.");
        }

    }

    private Endereco criarEndereco() {
        System.out.println("Digite o CEP: ");
        String cep = scanner.nextLine();

        System.out.println("Digite o Estado: ");
        String estado = scanner.nextLine();

        System.out.println("Digite a Cidade: ");
        String cidade = scanner.nextLine();

        System.out.println("Digite o Bairro: ");
        String bairro = scanner.nextLine();

        System.out.println("Digite a Rua: ");
        String rua = scanner.nextLine();

        System.out.println("Digite o Número: ");
        int numero = Integer.parseInt(scanner.nextLine());

        System.out.println("Digite o Complemento: ");
        String comp = scanner.nextLine();

        return new Endereco(cep, estado, cidade, bairro, rua, numero, comp);
    }
}
