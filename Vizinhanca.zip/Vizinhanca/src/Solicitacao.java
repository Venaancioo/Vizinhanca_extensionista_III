class Solicitacao {
    private int id;
    private String genero;
    private String descricao;
    private Endereco endereco;
    private Solicitante solicitante;

    public Solicitacao(int id, String genero, String descricao, Endereco endereco, Solicitante solicitante) {
        this.id = id;
        this.genero = genero;
        this.descricao = descricao;
        this.endereco = endereco;
        this.solicitante = solicitante;
    }

    public void exibir() {
        System.out.println("Solicitação ID: " + id + " | Gênero: " + genero +
                " | Descrição: " + descricao);
        solicitante.exibir();
        endereco.exibir();
    }

    public Endereco getEndereco() {
        return endereco;
    }
}