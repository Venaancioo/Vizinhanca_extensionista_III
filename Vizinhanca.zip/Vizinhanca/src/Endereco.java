class Endereco {
    private String cep;
    private String estado;
    private String cidade;
    private String bairro;
    private String rua;
    private int numero;
    private String complemento;

    public Endereco(String cep, String estado, String cidade, String bairro, String rua, int numero, String complemento) {
        this.cep = cep;
        this.estado = estado;
        this.cidade = cidade;
        this.bairro = bairro;
        this.rua = rua;
        this.numero = numero;
        this.complemento = complemento;
    }

    public void exibir() {
        System.out.println("Endereço: " + rua + ", " + numero + " - " + bairro +
                ", " + cidade + "/" + estado + " CEP: " + cep +
                " Complemento: " + complemento);
    }

    public String getCidade() {
        return cidade;
    }
}