class Solicitante {
    private String cnpj;
    private String razaoSocial;
    private String telefone;
    private String email;
    private String senha;
    private Endereco endereco;

    public Solicitante(String cnpj, String razaoSocial, String telefone, String email, String senha, Endereco endereco) {
        this.cnpj = cnpj;
        this.razaoSocial = razaoSocial;
        this.telefone = telefone;
        this.email = email;
        this.senha = senha;
        this.endereco = endereco;
    }

    public void exibir() {
        System.out.println("Solicitante: " + razaoSocial + " | CNPJ: " + cnpj +
                " | Email: " + email + " | Telefone: " + telefone);
        endereco.exibir();
    }

    public Endereco getEndereco() {
        return endereco;
    }
}