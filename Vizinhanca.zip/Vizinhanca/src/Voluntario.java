class Voluntario {
    private String cpf;
    private String nomeCompleto;
    private String telefone;
    private String email;
    private String senha;
    private String habilidades;
    private Endereco endereco;

    public Voluntario(String cpf, String nomeCompleto, String telefone, String email,
                      String senha, String habilidades, Endereco endereco) {
        this.cpf = cpf;
        this.nomeCompleto = nomeCompleto;
        this.telefone = telefone;
        this.email = email;
        this.senha = senha;
        this.habilidades = habilidades;
        this.endereco = endereco;
    }

    public void exibir() {
        System.out.println("Voluntário: " + nomeCompleto + " | CPF: " + cpf +
                " | Email: " + email + " | Telefone: " + telefone +
                " | Habilidades: " + habilidades);
        endereco.exibir();
    }

    public Endereco getEndereco() {
        return endereco;
    }
}